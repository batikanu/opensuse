ALTER TABLE subscription ADD "external" boolean NOT NULL DEFAULT false;
ALTER TABLE subscriptionhistory ADD "external" boolean NOT NULL DEFAULT false;