--------------------------------
-- REQ FTS Partner-Model - Roles
--------------------------------
INSERT INTO "organizationrole" ("tkey", "version", "rolename") VALUES (6, 0, 'BROKER');
INSERT INTO "organizationrole" ("tkey", "version", "rolename") VALUES (7, 0, 'RESELLER');
INSERT INTO "userrole" ("tkey", "rolename", "version") VALUES (6, 'BROKER_MANAGER', 0);
INSERT INTO "userrole" ("tkey", "rolename", "version") VALUES (7, 'RESELLER_MANAGER', 0);
