-- Japanese resource for V15.2.1 (replacement of words)
UPDATE localizedresource SET value='利用者情報' WHERE locale='ja' AND objecttype='REPORT_DESC' AND objectkey=0;
UPDATE localizedresource SET value='サービス利用部門情報' WHERE locale='ja' AND objecttype='REPORT_DESC' AND objectkey=3;
UPDATE localizedresource SET value='サービス利用部門の請求書明細' WHERE locale='ja' AND objecttype='REPORT_DESC' AND objectkey=10;
UPDATE localizedresource SET value='サービス仲介部門の売上配分明細' WHERE locale='ja' AND objecttype='REPORT_DESC' AND objectkey=15;
UPDATE localizedresource SET value='サービス提供代行部門の売上配分明細' WHERE locale='ja' AND objecttype='REPORT_DESC' AND objectkey=16;
UPDATE localizedresource SET value='サービス仲介部門/サービス提供代行部門の売上配分明細' WHERE locale='ja' AND objecttype='REPORT_DESC' AND objectkey=17;
UPDATE localizedresource SET value='売上配分明細' WHERE locale='ja' AND objecttype='REPORT_DESC' AND objectkey=18;
UPDATE localizedresource SET value='サービス提供部門の売上配分明細' WHERE locale='ja' AND objecttype='REPORT_DESC' AND objectkey=19;