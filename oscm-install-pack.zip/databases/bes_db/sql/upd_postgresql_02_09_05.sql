ALTER TABLE product ADD COLUMN customtaburl character varying(255) DEFAULT NULL;
ALTER TABLE producthistory ADD COLUMN customtaburl character varying(255) DEFAULT NULL;