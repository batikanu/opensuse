-- BUGFIX 11739
run:MigrateTriggerProcessParameters;