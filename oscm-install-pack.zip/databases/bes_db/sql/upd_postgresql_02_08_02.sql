ALTER TABLE "technicalproductoperationhistory" DROP COLUMN "operationtype";
ALTER TABLE "technicalproductoperation" DROP COLUMN "operationtype";