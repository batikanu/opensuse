ALTER TABLE "product" ADD COLUMN "paramconfigurl" VARCHAR(255);
ALTER TABLE "producthistory" ADD COLUMN "paramconfigurl" VARCHAR(255);