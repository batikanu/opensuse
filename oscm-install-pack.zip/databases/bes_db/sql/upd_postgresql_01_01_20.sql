ALTER TABLE "triggerprocess" ALTER COLUMN "user_tkey" DROP NOT NULL;
ALTER TABLE "triggerprocesshistory" ALTER COLUMN "userobjkey" DROP NOT NULL;