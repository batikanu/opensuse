ALTER TABLE "pricemodel" DROP COLUMN "periodhandling";
ALTER TABLE "pricemodelhistory" DROP COLUMN "periodhandling";