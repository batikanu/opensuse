INSERT INTO "hibernate_sequences" ("sequence_name", "sequence_next_hi_value") VALUES('CategoryToCatalogEntry', 10);
INSERT INTO "hibernate_sequences" ("sequence_name", "sequence_next_hi_value") VALUES('CategoryToCatalogEntryHistory', 10);
