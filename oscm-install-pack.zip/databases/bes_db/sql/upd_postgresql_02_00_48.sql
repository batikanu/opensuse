ALTER TABLE "catalogentry" DROP COLUMN "organization_tkey";
ALTER TABLE "catalogentryhistory" DROP COLUMN "organizationobjkey";