ALTER TABLE "marketplace" ADD COLUMN "trackingcode" TEXT;
ALTER TABLE "marketplacehistory" ADD COLUMN "trackingcode" TEXT;