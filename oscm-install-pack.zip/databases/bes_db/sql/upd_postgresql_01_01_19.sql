-- CREATE SCHEMA 

-- ----------------------------------------------
-- DDL-Anweisungen für Tabellen
-- ----------------------------------------------

ALTER TABLE "localizedresource" ADD COLUMN "version" INTEGER NOT NULL DEFAULT 0;

