ALTER TABLE "product" ADD COLUMN "autoassignuserenabled" BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE "producthistory" ADD COLUMN "autoassignuserenabled" BOOLEAN NOT NULL DEFAULT FALSE;

